import { h } from 'hyperapp'

export const SettingsDebug = () =>
    <div class="settings_content">Debug settings</div>