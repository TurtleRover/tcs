import { h } from 'hyperapp'

export const SettingsAbout = () =>
    <div class="settings_content">About settings</div>