import { h } from 'hyperapp'

export const SettingsGeneral = () =>
    <div class="settings_content">General settings</div>