import { h } from 'hyperapp'

export const SettingsNetwork = () =>
    <div class="settings_content">Network settings</div>