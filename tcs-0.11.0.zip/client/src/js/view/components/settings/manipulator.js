import { h } from 'hyperapp'

export const SettingsManipulator = () =>
    <div class="settings_content">Manipulator settings</div>