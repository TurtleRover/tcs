version = (0, 11, 0)
version_info = '.'.join(str(c) for c in version)
